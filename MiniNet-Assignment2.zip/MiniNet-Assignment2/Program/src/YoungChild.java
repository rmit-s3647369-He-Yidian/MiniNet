/**
 * 
 */
package MiniNet_2;


/**
 * @author s3647369_Yidian_He
 *
 */
public class YoungChild extends Child{

	public YoungChild(String firstname, String lastname, String image, String status, 
			char gender, int age, String state, String prt1, String prt2) {
		super(firstname, lastname, image, status, gender, age, state, prt1, prt2);
	}	

	
}
